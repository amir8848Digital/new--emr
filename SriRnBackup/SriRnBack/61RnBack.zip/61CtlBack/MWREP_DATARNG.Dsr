VERSION 5.00
Begin {BD4B4E61-F7B8-11D0-964D-00A0C9273C2A} MWREP_DATARNG 
   ClientHeight    =   7500
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   8280
   OleObjectBlob   =   "MWREP_DATARNG.dsx":0000
End
Attribute VB_Name = "MWREP_DATARNG"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
